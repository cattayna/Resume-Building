---
name: design-system-extractor
description: |
  Turns a reference design into a packaged design-system skill. The reference can be a screenshot/image/document someone uploads (Image Path), OR a brand or client name with no image provided (Web Research Path). Builds a mockup from the extracted system, then honestly compares and corrects both the system and the mockup. Use this skill whenever someone uploads a design and asks to "make a design system from this", "extract the brand/style from this site", "build a design system and then some mockups", "match this website's look", names a brand and asks to "build a design system for them", or says a mockup "does not look like" the reference. Also use it mid-task when a deliverable is challenged against its source. Do NOT use when there is no reference and no brand name (from-scratch belongs to general design work), or when the task is copy/content only.
license: Complete terms in LICENSE.txt
---
# Design System Extractor

## When to Use

Use this skill when:
- Someone uploads or links a reference design and wants a reusable
  design system built from it. → **follow Path A (Image)**
- Someone names a brand or client (e.g. "build a design system for
  AustralianSuper") with no image provided. → **follow Path B (Web
  Research)**
- A design system already exists and someone wants new mockups built to
  match it.
- Someone says a delivered mockup does not look like the reference they
  gave, and wants it compared and corrected.

Do not use this skill when:
- There is no reference at all and no brand name is given (a fresh
  brief with no example belongs to general design work, see the
  frontend-design skill instead).
- The task is copy or content only, with no visual system involved.

## Why the verification step is not optional

A design system built by naming colours and fonts off a screenshot will
still drift into generic defaults once actual pages get built: a
floating pill nav where the reference has a flush one, a missing hero
illustration, saturated colour blocks where the reference is mostly
white and grey, the wrong serif personality, monospace labels stamped
on everything. These are the field's common defaults and they will
happen again unless the build is checked against the source.

For the web research path, a different drift risk exists: AI-generated
or aggregated third-party "brand colour" pages frequently publish
unverified palette values that conflict with the brand's actual
published assets. Using those values produces a system that is
confidently wrong. Cross-referencing primary sources is not optional.

This skill treats verification as a required step in both paths.

---

## Path A — Image Extraction Workflow

Use when a reference image, screenshot, or document has been uploaded.

### A1. Intake and scope

Read the reference file with `view`. If it is a long screenshot, treat
it as a full page capture: note its actual pixel dimensions before
doing anything else. Confirm scope before building — full site vs one
page, reference's own product vs style donor. If ambiguous, ask one
direct question rather than assuming the larger interpretation.

### A2. Deconstruct the reference

Crop into distinct regions (nav, hero, card grid, footer) and `view`
each individually. Sample pixel colours with a script — do not guess
hex from how a colour looks on screen. Describe the typeface character
before naming a font. Identify what carries the brand personality (one
or two elements) vs neutral chrome — do not spread the "loud" treatment
everywhere. See `reference/deconstruction-checklist.md`.

### A3. Package the design system

Build a `SKILL.md` plus a `references/` folder. Encode findings as
concrete tokens: colour table with permitted/prohibited contexts, type
scale with named families and weights, component patterns for elements
that recurred in the reference, imagery guidance.

### A4. Build the deliverable

Build the mockup using the packaged tokens, grounded in the real
subject matter — not a generic template.

### A5. Compare, honestly

1. Render the built mockup to an image.
2. Crop matching regions (nav to nav, hero to hero, card to card) and
   place side by side.
3. Work through `reference/comparison-checklist.md` region by region.
   Write concrete specific mismatches: "nav is a floating blurred pill;
   reference is flush" — not "nav feels different".
4. State gaps plainly before the person has to point them out.

### A6. Correct and repackage

Fix the skill files first (write the correction in explicitly), then
rebuild the deliverable from the corrected system. Re-render, re-check,
repackage. Be specific about what changed and why.

---

## Path B — Web Research Extraction Workflow

Use when a brand or client name is given but no image has been uploaded.
This path was established when building the AustralianSuper design
system skill from web sources with no reference image available.

### B1. Intake and scope

Confirm the brand name, scope (full design system or specific
deliverable type), and whether this is the master brand or a sub-brand.
If ambiguous, ask one direct question before searching.

### B2. Source brand assets — primary sources first

Search in this priority order:

**Tier 1 — Direct asset extraction (highest confidence, use as primary)**
- **Brandfetch** (`brandfetch.com/[brand]`) — extracts hex, RGB, and
  CMYK values directly from published SVG/CSS assets, not from
  eyeballing a screenshot. Also provides SVG logo dimensions.
- The brand's **official style guide or brand portal** if publicly
  accessible.
- The brand's **live website CSS** — inspect for `--color-*` custom
  properties and `font-family` declarations.

**Tier 2 — Cross-reference (confirm, do not use as sole source)**
- Brand's own annual reports or investor materials.
- Wikipedia infobox logo (source SVG sometimes carries accurate values).

**Tier 3 — Disregard unless confirmed by Tier 1**
- AI-generated aggregator sites (brandcolors.net, schemecolor.com,
  random design blogs). These frequently publish unverified values.
  If a Tier 3 value conflicts with Tier 1, use Tier 1 and note the
  conflict explicitly in the skill file.

> **AustralianSuper precedent:** Brandfetch returned five confirmed
> colours. Third-party sites claimed navy `#003366` and teal `#00A9A5`
> as primary colours — these conflicted with Brandfetch and were
> discarded. The skill file explicitly flags this so future builds do
> not regress.

### B3. Extract logo geometry

From Brandfetch or the brand's SVG:
- Read the native `viewBox` or `width`/`height` to get the true aspect
  ratio. Do not assume square, 3:1, or 4:1.
- Note whether a symbol-only version exists for footers/small contexts.
- Note stroke character (uniform vs. contrast strokes).

> **AustralianSuper precedent:** SVG was 193 × 38 px — a 5:1 ratio.
> Assuming 3:1 would have produced a logo that looked too square in
> every slide layout.

### B4. Identify the typeface

Most brand wordmarks use a custom or licensed typeface not commercially
available. Process:
1. Search `[brand] typography` or `[brand] brand font`.
2. Describe the letterform character: stroke contrast (uniform vs.
   modulated), aperture, terminal style, x-height, personality.
3. From that description, name the closest public substitute —
   not just the first sans-serif that comes to mind. Common
   substitutes for neutral-warmth uniform-stroke brands: Aktiv
   Grotesk, FS Me, GT Walsheim, Neue Haas Grotesk.
4. Document the custom font name and the substitute's rationale in
   the skill file.

> **AustralianSuper precedent:** Uses a bespoke uniform-stroke
> custom sans. Initial default was Avenir Next. After analysis,
> Aktiv Grotesk and FS Me were identified as closer matches based
> on stroke uniformity and personality. Avenir Next downgraded to
> fallback.

### B5. Research usage patterns

Search for `[brand] brand guidelines`, `[brand] annual report`, and
check the live website. Document:
- Which colour is dominant (large surfaces) vs accent (one CTA per
  region).
- The brand's primary personality carrier — usually one or two elements
  (a motif, illustration style, layout device), not a whole-page
  treatment.
- Whether gradient versions of assets exist and when they are permitted.

### B6. Source integrity documentation

For every material token, record its source tier in
`references/brand-tokens.md`. Include:
- Where the hex value came from.
- Any conflicting values found and why they were discarded.
- The date the data was retrieved.

This is not optional. Without it, the next build from the same skill
silently regresses to whatever the model's training data says.

**Standard note format:**
```
> **Source note:** Colour values confirmed via [source] ([date]).
> [Third-party source] claims [conflicting value] — conflicts with
> [Tier 1 source] and has been disregarded.
```

### B7. Package the design system

Same structure as A3, with additions:
- Colour token table: hex, RGB, CMYK, official brand names, permitted
  and prohibited contexts, source note.
- Logo reference table: native dimensions, aspect ratio, clear space,
  white vs. colour version rules.
- Typography: custom font name (if any), preferred public substitute
  with rationale, fallback.
- Troubleshooting section naming the specific drift risks for this
  brand (e.g. wrong logo ratio, colour over-application, motif misuse).

### B8. Build the deliverable

Same as A4.

### B9. Verify against the token system

Without a pixel-level reference image, verification is checklist-driven:
1. Run the skill's quality checklist against the deliverable.
2. Confirm every hex value in the output matches the token table.
3. Confirm the logo aspect ratio is correct in the output.
4. Confirm no monospace, decorative serif, or generic system font has
   crept into any label or caption role.
5. State any items that could not be verified without a rendered
   reference image, and flag for manual review.

### B10. Correct and repackage

Same as A6: fix skill files first, rebuild deliverable, repackage.

## Quality Checklist

**Source integrity (Path B only)**
- [ ] All hex values sourced from Tier 1 (Brandfetch or official brand
      portal), not Tier 3 aggregators.
- [ ] Conflicting third-party values explicitly named and discarded in
      `references/brand-tokens.md` with a dated source note.
- [ ] Logo aspect ratio confirmed from SVG dimensions, not assumed.
- [ ] Typeface character described before a substitute was named;
      substitute rationale documented.

**Design system completeness (both paths)**
- [ ] Scope confirmed before building.
- [ ] Colour tokens include permitted and prohibited contexts, not just
      hex values.
- [ ] Typography tokens include custom font name (if any), preferred
      public substitute with rationale, and fallback.
- [ ] Component patterns documented for elements that appear in the
      brand's actual communications.
- [ ] Troubleshooting section names the specific drift risks for this
      brand.

**Deliverable verification (both paths)**
- [ ] Path A: deliverable rendered and compared against reference
      region by region before presenting.
- [ ] Path B: quality checklist run; logo ratio confirmed; hex values
      confirmed against token table; no font drift.
- [ ] Any mismatches or unverifiable items stated plainly.
- [ ] Corrections written into the skill files, not just the output.

## Troubleshooting

**Path A — Image**
- **Rebuild looks like a generic SaaS template** — check for a
  floating blurred nav pill (should be flush), no hero illustration,
  saturated colour blocks as card backgrounds, decorative serif,
  monospace metadata labels. See `reference/common-drift-patterns.md`.
- **Comparison step feels redundant** — extracting correct token values
  does not guarantee they are applied the way the reference applies
  them. The comparison catches application drift.
- **No headless render tool available** — use a static side-by-side
  of cropped reference regions against manual HTML/CSS reasoning as
  a fallback. Prefer rendering whenever a tool is available.

**Path B — Web Research**
- **Colour values conflict between sources** — always use Tier 1 over
  Tier 3. Document the conflict explicitly; do not silently pick one.
- **No Brandfetch entry for this brand** — fall back to inspecting
  the live website CSS for `--color-*` custom properties, or check
  the brand's official annual report.
- **Logo looks too compact or too wide** — read the SVG native
  dimensions. Do not assume any ratio; read the actual `viewBox`.
- **Typography defaults to a generic sans** — describe letterform
  character before naming a substitute. Check stroke contrast,
  aperture, and x-height. Generic sans-serifs (Helvetica, Arial,
  Avenir Next) are often not the best match.
- **Skill has no source note** — add one. Without it, the next build
  silently regresses to whatever training data says, which may be wrong.

## References

- `reference/deconstruction-checklist.md` — region-by-region questions
  for image-based extraction (Path A).
- `reference/comparison-checklist.md` — side-by-side comparison method
  and table format (Path A).
- `reference/common-drift-patterns.md` — specific ways a rebuild drifts
  from its reference, with fixes.
- `reference/web-research-sources.md` — source tier table and search
  query templates for brand research (Path B).
- `scripts/compare.py` — helper functions for cropping regions and
  sampling pixel colours at coordinates (Path A).

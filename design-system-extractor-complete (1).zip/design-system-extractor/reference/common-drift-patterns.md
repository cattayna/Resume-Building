# Common Drift Patterns

These are the specific ways a rebuild tends to drift away from a
reference design, generalised from real corrections. Check for these
by name; they are common enough to be worth naming rather than
rediscovering each time.

## 1. The floating pill nav

**Drift**: wrapping the navigation in a rounded, blurred, shadowed
"card" that floats over the page, even when the reference's nav sits
flush against its background with no container at all.

**Why it happens**: a floating blurred nav is a common current default
for "modern SaaS" pages, so it gets reached for automatically.

**Fix**: check the reference specifically. If the nav has no visible
border, shadow, or background separate from the page behind it, the
rebuild's nav should not have one either.

## 2. The missing hero illustration

**Drift**: building a hero with the right gradient or background colour
but no actual illustration, or substituting a flat colour swatch for
what the reference shows as a detailed illustrated scene.

**Why it happens**: illustration is the most labour-intensive part of
matching a reference, so it is easy to plan for and then skip, or to
generate a token/CSS variable for it that never gets used in the actual
markup.

**Fix**: treat the illustration as a required element, not a nice
extra. If a placeholder is used during drafting, flag it explicitly
rather than letting it stand in silently.

## 3. Saturated colour where the reference is neutral

**Drift**: giving every card, category, or status its own solid,
saturated colour fill, when the reference is mostly white/grey/cream
with colour reserved for one hero moment or a single accent.

**Why it happens**: colour-coding by category feels informative and is
a common dashboard pattern, so it gets applied by default even when
the reference does not use it.

**Fix**: estimate the neutral-to-accent colour ratio in the reference
before building, and hold the rebuild to roughly the same ratio. Move
category or type distinctions into a small icon, badge, or text label
instead of a full-colour fill.

## 4. The wrong serif personality

**Drift**: picking a display serif for its general "editorial" or
"literary" association without checking whether it matches the
reference's specific personality. A high-contrast, ink-trap, or
swash-heavy serif reads as a completely different brand from a calm,
even-stroke editorial serif, even though both are "serifs".

**Why it happens**: serif choice is often made from a mental shortlist
of "nice serif fonts" rather than from the actual letterforms in the
reference.

**Fix**: describe the reference's letterforms in plain words first
(stroke contrast, presence of ink traps or swashes, weight) and pick a
typeface that matches that description, not the first serif that comes
to mind.

## 5. Monospace overuse

**Drift**: applying a monospace label style to every piece of secondary
text (source, location, count, price) because it looks "structured" and
on-brand, when the reference uses monospace rarely, for one or two
specific captions.

**Why it happens**: once a monospace token exists in the system, it is
easy to reach for it as the default treatment for any small text.

**Fix**: count the monospace instances in the reference before
building. If the reference uses it once or twice per screen, hold the
rebuild to a similar rate; move the rest of the secondary text to the
body sans font.

## 6. Trusting the system before verifying it

**Drift**: after extracting tokens from a single glance at a reference,
committing to a component pattern (like a floating pill nav) in the
design system document itself, so every subsequent build inherits the
mistake automatically.

**Why it happens**: the design system is meant to prevent drift by
codifying patterns, but if the pattern was wrong at extraction time,
the system now actively enforces the wrong thing.

**Fix**: this is exactly what the comparison step (see
`comparison-checklist.md`) is for: verify the system's own component
patterns against the reference before trusting them as the source of
truth, and correct the system document itself when a mismatch is
found, not just the one deliverable that surfaced it.

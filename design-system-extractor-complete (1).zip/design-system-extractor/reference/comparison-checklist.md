# Comparison Checklist

Use this once a mockup or page has been built from the extracted design
system, before presenting it as finished.

## Method

1. Render the built page to a static image. A headless screenshot tool
   is enough; if it cannot reach the network for a webfont, the layout
   and colour comparison is still valid.
2. Identify the same regions in both the original reference and the new
   render (nav, hero, a card, a footer, any full-bleed section).
3. Crop matching regions from each and place them in a single image,
   original on top, new render below, at the same width.
4. View the composite and note concrete differences, not impressions.

## Region-by-region questions

For each matched pair of crops, answer directly:

- **Nav**: same container treatment (flush versus floating card)? Same
  link style and count? Same button shape and placement?
- **Hero**: same background treatment? Is there an illustration in the
  original, and is there an equivalent illustration in the render, not
  just a colour fill standing in for one? Same heading personality
  (serif weight, size, line breaks)?
- **Cards**: same colour distribution (is the render using solid
  colour banners where the original uses a small image or icon)? Same
  border, radius, and shadow weight?
- **Colour overall**: estimate the neutral-versus-accent ratio in each
  and compare. A render that is visibly more colourful than its
  reference has drifted.
- **Type**: does the headline typeface carry the same personality
  (calm versus quirky, weight, contrast)? Is monospace used at the same
  rate (rare captions) or has it spread to every metadata field?

## Reporting format

Present findings as a direct table, not prose hedging:

| Region | Original | Rebuild | Verdict |
|---|---|---|---|
| Nav | Flush, plain text links, one pill CTA | Floating blurred pill container | Mismatch |
| Hero | Full-bleed illustration anchored right | No illustration present | Mismatch |
| Cards | White, one small icon, mostly text | Solid saturated colour banner per card | Mismatch |
| Card radius/shadow | Soft radius, light shadow | Soft radius, light shadow | Match |

State the verdict plainly (Match / Mismatch), not softened language.
Each mismatch row should be specific enough that fixing it is
unambiguous: name what is different, not just that something feels off.

## When everything matches

If the comparison genuinely finds no mismatches, say so, but only after
having actually gone through each region; do not skip the check because
the build "should" be correct. The check exists because "should be
correct" is exactly the assumption that produces drift.

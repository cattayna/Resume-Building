# Deconstruction Checklist

Work through these regions on the reference image before writing any
tokens. Crop each region out and view it at a legible size rather than
reading it off the full page thumbnail.

## Navigation
- Is it flush against the background behind it, or a floating card
  with its own shadow, blur, or border?
- How many links, and are they plain text or styled as buttons?
- Is there exactly one strong call-to-action button, and what shape is
  it (pill, rounded rectangle, square)?

## Hero (or the first screen's worth of content)
- What is the background: flat colour, gradient, image, illustration,
  video?
- Where does the eye go first: a headline, an illustration, a product
  shot, a number?
- Is there an illustration or graphic element, and how detailed is it
  (flat single-colour shapes, shaded/layered illustration, photograph)?
- How many calls to action, and what is the visual hierarchy between
  them (solid versus outline, size difference)?

## Typography
- Serif or sans for headlines? Describe the personality in plain words
  first (calm/editorial, quirky/high-contrast, geometric, humanist)
  before naming a specific typeface.
- Is there a distinct label or caption typeface (often monospace), and
  where exactly does it appear? Count the instances; if it is on every
  piece of text, that is different from appearing on two or three
  specific captions.
- What is the body text size and line length doing: dense and
  information-heavy, or generous and editorial?

## Colour
- List every distinct colour visible, then note where each one
  appears: hero only, one illustration, a single status indicator, or
  spread across many components.
- What fraction of the page, by area, is a neutral (white, grey, cream,
  black/ink) versus a saturated accent colour? A reference that is 90%
  neutral will not tolerate a rebuild that is 40% saturated colour.

## Cards and repeated components
- What varies between card instances (colour, image, layout) and what
  stays constant (border, radius, shadow, spacing)?
- Is there a colour-coded system (different colour per category), or is
  colour reserved for a specific purpose (status, a single accent)?

## Illustration and imagery style
- Flat shapes or shaded/layered? How many tones per illustrated
  element (a hill in one green, or two greens for shading)?
- Subject matter: literal and grounded, or abstract?
- Does the illustration repeat across the page, or appear once as a
  hero moment?

## Structural devices
- Dividers, seams, or transitions between sections: are they plain
  hairlines, or a distinctive treatment worth naming as a signature
  element?
- Numbering, eyebrows, or labels: do they encode real structure (an
  actual sequence, an actual timestamp) or are they decorative?

## Spacing and density
- Generous whitespace or dense information layout?
- Content max-width relative to viewport: does content breathe with
  margin, or run close to the edges?

# Web Research Sources — Brand Extraction (Path B)

Reference for Step B2 of the Design System Extractor workflow.

---

## Source Tier Table

| Tier | Source type | Examples | Confidence | Use as |
|------|-------------|----------|------------|--------|
| 1 | Direct asset extraction | Brandfetch, official brand portal, live website CSS | High | Primary |
| 2 | Brand's own publications | Annual report, investor deck, brand guide PDF | Medium | Cross-reference |
| 3 | AI-generated aggregators | brandcolors.net, schemecolor.com, design blogs | Low | Disregard unless Tier 1 confirms |

---

## Search Query Templates

### Colour and logo assets
```
brandfetch.com/[brand-domain]
[brand name] brand guidelines
[brand name] brand portal
[brand name] colour palette site:[brand-domain].com
[brand name] annual report [year]
```

### Typography
```
[brand name] brand font typography
[brand name] typeface
[brand name] font family site:[brand-domain].com
```

### Usage patterns and motifs
```
[brand name] brand guidelines PDF
[brand name] design system
[brand name] presentation template
[brand name] communications style
```

### Logo geometry (when Brandfetch is unavailable)
```
[brand name] logo SVG download
[brand name] logo vector
[brand name] brand assets download
```

---

## Brandfetch Reading Guide

When reading a Brandfetch result:

| Field | What to capture |
|-------|----------------|
| Colors | Hex, RGB, and CMYK for each colour; note the label name (e.g. "Tolopea") |
| Fonts | Family name; note if listed as "custom" or unlicensed |
| Logos | Check the SVG source for `viewBox` or explicit `width`/`height` — this gives the true aspect ratio |
| Format | Note if both a wordmark and a symbol/icon version exist |

---

## Conflict Resolution Protocol

When sources disagree:

1. Record both values and their sources.
2. Use the Tier 1 value.
3. Write a source note in `references/brand-tokens.md` naming the
   conflict and the reason for the choice.
4. Never silently pick one — the note is what prevents future regression.

**Standard note format:**
```
> **Source note:** [Token] confirmed via [Tier 1 source] ([date]).
> [Tier 3 source] claims [conflicting value] — this conflicts with
> [Tier 1 source] and has been disregarded.
```

---

## Precedents

### AustralianSuper (October 2026)
| Item | Finding | Source |
|------|---------|--------|
| Primary colour | `#260046` (Tolopea) | Brandfetch T1 |
| Accent colour | `#D93E02` (Grenadier) | Brandfetch T1 |
| Conflicting claim | Navy `#003366`, teal `#00A9A5` | T3 aggregators — discarded |
| Logo ratio | 5:1 (193 × 38 px SVG) | Brandfetch T1 |
| Typeface | Custom bespoke sans (not licensed) | Web research T2 |
| Substitute | Aktiv Grotesk / FS Me | Letterform analysis |
| Initial default avoided | Avenir Next (too generic) | — |

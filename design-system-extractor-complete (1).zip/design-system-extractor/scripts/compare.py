"""Helper functions for the design-system-extractor skill.

Two jobs:
1. Crop a reference (or rendered) image into named regions for closer
   viewing, since a single full-page screenshot is too small to judge
   detail against.
2. Sample pixel colours at specific coordinates so tokens are pulled
   from real values rather than guessed from how a colour looks on
   screen.

Usage is meant to be interactive: crop a region, view it, adjust the
box, re-crop, rather than guessing coordinates once and moving on.
"""

from PIL import Image


def get_dimensions(path):
    with Image.open(path) as img:
        return img.size


def crop_region(path, box, out_path):
    """box = (left, top, right, bottom) in source pixels."""
    with Image.open(path) as img:
        img.convert("RGB").crop(box).save(out_path)
    return out_path


def sample_colours(path, points):
    """points = {"label": (x, y), ...}. Returns {"label": (r,g,b), ...}."""
    with Image.open(path).convert("RGB") as img:
        return {label: img.getpixel(xy) for label, xy in points.items()}


def side_by_side(path_a, path_b, box_a, box_b, out_path, gap=20):
    """Crop matching regions from two images and stack them vertically,
    original on top, rebuild below, for a direct visual comparison."""
    with Image.open(path_a).convert("RGB") as a, Image.open(path_b).convert("RGB") as b:
        crop_a = a.crop(box_a)
        crop_b = b.crop(box_b)
        w = max(crop_a.width, crop_b.width)
        h = crop_a.height + crop_b.height + gap
        canvas = Image.new("RGB", (w, h), "white")
        canvas.paste(crop_a, (0, 0))
        canvas.paste(crop_b, (0, crop_a.height + gap))
        canvas.save(out_path)
    return out_path


def rgb_to_hex(rgb):
    return "#{:02X}{:02X}{:02X}".format(*rgb)


if __name__ == "__main__":
    import sys
    if len(sys.argv) > 1:
        print(get_dimensions(sys.argv[1]))

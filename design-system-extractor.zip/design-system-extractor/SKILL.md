---
name: design-system-extractor
description: >
  Turns a reference design (a screenshot, image, or document someone
  uploads) into a packaged design-system skill, then builds a requested
  mockup or deliverable from it, then honestly compares the result back
  against the original reference and corrects both the system and the
  mockup based on concrete findings. Use this skill whenever someone
  uploads a design, screenshot, or inspo image and asks to "make a
  design system from this", "extract the brand/style from this site",
  "build a design system and then some mockups", "match this website's
  look", or says a mockup "does not look like" or "does not match" the
  reference they gave you. Also use it mid-task if a delivered mockup is
  challenged against its source reference. Do NOT use this skill when
  there is no reference design to extract from (a from-scratch brief
  with no image or example to match), or when the request is purely
  about content/copy with no visual system involved.
license: Complete terms in LICENSE.txt
---

# Design System Extractor

## When to Use

Use this skill when:
- Someone uploads or links a reference design and wants a reusable
  design system built from it.
- A design system already exists and someone wants new mockups built to
  match it.
- Someone says a delivered mockup does not actually look like the
  reference they gave, and wants it compared and corrected.

Do not use this skill when:
- There is no reference design at all (a fresh brief with no example to
  match belongs to general design work, see the frontend-design skill
  instead).
- The task is copy or content only, with no visual system involved.

## Why the comparison step is not optional

A design system built by naming colours and fonts off a screenshot will
still drift into generic defaults once actual pages get built: a
floating pill nav where the reference has a flush one, a missing hero
illustration, saturated colour blocks where the reference is mostly
white and grey, the wrong serif personality, monospace labels stamped
on everything instead of used once. These are not random mistakes,
they are the field's common defaults, and they will happen again unless
the build is checked against the source image directly, region by
region, not against a memory of what was extracted.

This skill treats that check as a required step, not a nice-to-have.

## Workflow

### 1. Intake and scope

Read the reference file with `view`. If it is a long screenshot, treat
it as a full page capture: note its actual pixel dimensions before
doing anything else (a quick script check is fine).

Confirm scope before building anything substantial:
- Is the ask a full multi-page site, or one page/component shown in a
  few layout variations?
- Is the deliverable meant to look like the reference's own product, or
  is the reference purely a style donor for a different product or
  subject?

If either is ambiguous, ask one direct question rather than assuming
the larger, more expensive interpretation. Guessing "rebuild the whole
site" when someone meant "one page, a few variations of it" wastes the
whole first pass.

### 2. Deconstruct the reference

Do not eyeball a single full-length screenshot and start extracting
tokens from memory. Instead:

1. Check the image's actual dimensions.
2. Crop it into its distinct regions (nav, hero, card grid, feature
   rows, footer, any full-bleed colour sections) and `view` each crop
   individually at a size where details are legible.
3. Sample actual pixel colours from key regions (background, primary
   accent, text, button fill, borders) rather than guessing hex values
   from how a colour looks on screen. A short script using an image
   library to read pixel RGB values at specific coordinates is enough.
4. Name the typeface personality specifically: serif or sans, calm and
   editorial versus quirky and high-contrast, weight, letter-spacing.
   Do not jump to the first familiar font name; describe what you see
   first, then pick a real typeface that matches the description.
5. Note what carries the brand's personality versus what is neutral
   chrome. In most references, one or two elements do the personality
   work (an illustration style, a specific gradient, a signature
   layout device) and everything else is quiet. Identify which is
   which; do not spread the "loud" treatment across every component.

See `reference/deconstruction-checklist.md` for the full list of
regions and questions to work through.

### 3. Package the design system as a skill

Build a `SKILL.md` plus a `reference/` folder following the standard
skill scaffold (name, description with trigger phrases and a "do not
use" clause, then a body covering tokens, type, components, imagery,
workflow, quality checklist, troubleshooting). Encode the findings from
step 2 as concrete tokens and rules, not vibes:
- A colour token table with hex values and, critically, where each
  colour is allowed to appear (a hero-only accent is not the same as a
  colour safe to use as a card background).
- A type scale with named families and specific weights.
- Explicit component patterns for the elements that recurred in the
  reference (nav treatment, hero structure, card anatomy, button
  hierarchy).
- Imagery or illustration guidance, including how much detail and
  colour density is expected.

Zip the folder so it can be added as a skill from Settings.

### 4. Build the requested deliverable

Build the actual mockup or page using the packaged tokens, grounded in
the real subject matter of the request (see the frontend-design skill's
guidance on grounding a design in its subject, not a generic template).
The design system supplies the visual language; the content and layout
still need to be built for what was actually asked for.

### 5. Compare, honestly

Before presenting the result as finished, compare it back against the
original reference:

1. Render the built mockup to an image (a headless screenshot tool is
   sufficient even if some assets like remote fonts fail to load; a
   layout and colour check does not need perfect font rendering).
2. Crop matching regions from the original reference and the new
   render (nav to nav, hero to hero, card to card) and place them
   side by side.
3. Work through `reference/comparison-checklist.md` region by region
   and write down concrete, specific mismatches, not a general
   impression. "The nav is a floating blurred pill; the reference nav
   is flush with no container" is useful. "The nav feels different" is
   not.
4. If the comparison surfaces real gaps, say so plainly, including to
   the person, before they have to point it out. Owning a miss clearly
   and specifically is more useful than a vague acknowledgement.

### 6. Correct the system and the deliverable together

Fix the design system's SKILL.md and reference files first, writing the
correction into the document explicitly (a short "how this was
corrected" note naming the specific mistake helps the system resist the
same drift next time). Then rebuild the deliverable from the corrected
system, not by patching the old output in place, so the fix is
systemic rather than cosmetic.

### 7. Re-verify and package

Re-render and re-compare the corrected result against the same regions
checked in step 5. Repackage the design system zip with the corrected
reference files. Present the corrected deliverable alongside the
updated design system, and be specific about what changed and why.

## Quality Checklist

- [ ] Scope (full site versus one page/component, and whose product
      the deliverable represents) was confirmed before building.
- [ ] The reference was deconstructed region by region with actual
      colour sampling, not extracted from a single glance.
- [ ] The design system encodes where each colour and typographic
      choice is allowed to appear, not just that it exists.
- [ ] The built deliverable was rendered and compared against the
      reference region by region before being presented as finished.
- [ ] Any mismatches found were stated specifically and corrected in
      both the system and the deliverable, not just the deliverable.
- [ ] The design system documents the correction so it does not
      recur on the next build from the same system.

## Troubleshooting

- **The rebuild still looks like a generic SaaS template** - check for
  the field's common defaults specifically: a floating blurred nav pill
  where the reference has none, no hero illustration or a flat colour
  fill standing in for one, saturated colour blocks used as card
  backgrounds, a decorative high-contrast serif where the reference is
  calm and editorial, monospace labels on every piece of metadata. See
  `reference/common-drift-patterns.md` for the full list with fixes.
- **The comparison step feels redundant because the tokens were
  "extracted correctly"** - extracting the right token values does not
  guarantee they get applied the way the reference applies them.
  Colour and font names are necessary but not sufficient; the
  comparison step is what catches drift in application, not
  extraction.
- **No headless render tool is available** - a static side-by-side of
  cropped screenshots from the reference against careful manual
  reasoning about the built HTML/CSS is a fallback, but a real render
  catches spacing and colour problems that reasoning about code alone
  will miss. Prefer rendering whenever any tool for it is available.

## References

- `reference/deconstruction-checklist.md` - the region-by-region
  questions to work through when analysing a reference design.
- `reference/comparison-checklist.md` - the side-by-side comparison
  method and table format for reporting findings.
- `reference/common-drift-patterns.md` - the specific ways a rebuild
  tends to drift from a reference, with fixes for each.
- `scripts/compare.py` - helper functions for cropping an image into
  regions and sampling pixel colours at coordinates.

---
name: pptx-slide-recreator
description: "Analyses a PowerPoint slide supplied as an image, screenshot, PPTX, XML export or detailed description, then generates a self-contained PPTXGenJS script that reproduces it as an editable .pptx file. Make sure to use this skill whenever the user wants to recreate, rebuild, clone, reverse-engineer or reproduce an existing slide, process diagram, SmartArt-style graphic or slide layout as an editable PowerPoint, or asks for PPTXGenJS/JavaScript code to generate a slide that matches a source image. Also use it when the user wants a design audit of a slide (colour palette, typography, shape geometry, spacing) before rebuilding it. Do NOT use this skill for building a brand-new presentation from scratch with no source slide to match (use the general pptx skill instead), and do NOT default to HTML, React, Vue, SVG or CSS output unless the user explicitly asks for one of those formats.\n"
---

# PowerPoint Slide Design Analyser & JavaScript PPT Artifact Generator

## Role

Act as an expert PowerPoint engineer, presentation design systems analyst
and JavaScript developer. Given a source slide, produce an editable
`.pptx` that visually matches it as closely as possible, built from native
PowerPoint shapes via PPTXGenJS, not a flattened image.

## When to Use

Use this skill when the user:
- Supplies a slide image, screenshot, `.pptx`, XML export or detailed
  written description and asks to recreate, rebuild or clone it.
- Asks for "PPTXGenJS code" or "JavaScript to generate a PowerPoint slide"
  that matches a source.
- Wants a design audit (colours, fonts, spacing, shape geometry) of an
  existing slide before or instead of rebuilding it.
- Describes a process diagram, chevron sequence, or SmartArt-style graphic
  they want reproduced as editable PowerPoint shapes.

Do not use this skill when:
- There is no source slide to match (a from-scratch deck request belongs
  with the general `pptx` skill, not this one).
- The user explicitly wants HTML, React, Vue or SVG output instead of an
  editable `.pptx` (only produce those if asked; see `references/web-output.md`).

## Output Target (defaults)

Unless the user says otherwise:

| Setting | Default |
|---|---|
| Primary output | Editable `.pptx` |
| JavaScript library | PPTXGenJS |
| Slide ratio | Match the source slide; fall back to 16:9 widescreen |
| Measurement system | Inches for PowerPoint coordinates |
| Content model | A single editable data object (see `scripts/slide-data-model-example.js`) |
| Shape preference | Native PowerPoint shapes over images or HTML approximations |
| Validation | Render the generated slide and compare it visually against the source |

If the source does not use a standard slide ratio, preserve the visible
source ratio rather than forcing 16:9.

## PPT Creation Rules (Design Craft)

Before auditing or rebuilding anything, hold the slide to the six design
fundamentals below. They apply whenever a design decision must be made
rather than simply copied from the source: when the source is ambiguous
or incomplete and a judgement call is needed, when the user asks for a
new slide rather than a recreation, or when the user asks for a design
review or critique rather than a rebuild. Read
`references/ppt-creation-rules.md` for the full guiding principle,
five-question checklist and "what good looks like" examples behind each
fundamental.

1. **Audience** — who the slide is for, what they already know, what
   they need to know first, the document's purpose, and the message to
   give.
2. **Layout** — what needs to be seen first, how many points are being
   made, whether something can be shown instead of told, whether items
   are grouped simply, and whether anything is repeated.
3. **Colours** — what needs to be seen quickly, whether the colours pair
   well and make sense, and whether too many or too few colours are in
   play. Colour must always have a job: focus attention, evoke an
   emotion, or group like elements.
4. **Spacing & Sizing** — even spacing and alignment, consistent sizing
   of like elements, consistent position across slides, and enough
   whitespace that the design can breathe.
5. **Typography** — a clear text hierarchy, consistent size/weight/font,
   clearly grouped text, and consistent line counts across parallel
   blocks.
6. **Icons & Images** — whether a visual communicates better than text,
   whether icons and images make sense and fit the slide design, and
   whether images are high resolution and in focus.

Close every design task with the four habits in
`references/ppt-creation-rules.md`: be inspired by good design
elsewhere, understand the slide's message before building it, get a
second opinion, and iterate rather than treating the first draft as
final. Perceptions of "good" design are subjective; the real test is
whether the slide clearly communicates its message and helps the
audience decide faster.

If the user is also asking about manual PowerPoint editing speed
(shortcuts, the Quick Access Toolbar, an accelerator/elements pack,
gradient or merge-shape tricks, or in-app AI copilots), see
`references/powerpoint-shortcuts-and-tricks.md`. That material speeds up
a human editing the output by hand; it does not change how the
PPTXGenJS script itself is written.

## Workflow

Work through these steps in order. Read the referenced file before the
step that needs it rather than loading everything up front.

### Step 1: Design Audit

Analyse the supplied slide and extract, without inventing anything not
visibly present: canvas/slide dimensions, layout and region geometry
(x/y/w/h in both px and inches), the full colour palette (including
gradients), every distinct text style, a component inventory mapped to
PowerPoint shape types, spacing/border rules, and non-rectangular shape
geometry.

Read `references/design-audit-checklist.md` for the full set of
categories, fields to record and worked examples for each.

### Step 2: Design Rules

Summarise the slide's implicit design system as a short numbered list
(e.g. "process stages run left to right", "green headers pair with
green-tinted panels", "no decorative diagonal line is present"). Colours
encode meaning and must not be changed for stylistic preference; do not
add borders, shadows or separators that are not visible in the source.

### Step 3: PowerPoint Component Mapping

Map every audited element to an implementation, in this priority order:
native shape → native text box → table/chart → connector → SVG → freeform
polygon → raster image → HTML/CSS (only if explicitly requested).

Never simulate a native shape (e.g. a chevron) using skewed rectangles,
decorative diagonal lines or layered overlapping shapes that create
visible seams. If the design resembles SmartArt, describe it as
"SmartArt-style" rather than asserting it is literal SmartArt unless the
source confirms it.

### Step 4: Slide Artifact Data Model

Build one structured JavaScript data object holding all editable content
and style values (metadata, slide dimensions, typography tokens, colour
tokens, and a `steps`/`elements` array). No user-editable text should be
hardcoded inside rendering functions.

See `scripts/slide-data-model-example.js` for a complete worked example
structure to adapt.

### Step 5: JavaScript PowerPoint Generation

Generate self-contained PPTXGenJS code that creates the presentation, sets
the correct slide layout, adds every shape and text box as editable
objects via reusable rendering functions, preserves z-order and aspect
ratio, and writes the `.pptx`.

Use `scripts/pptxgenjs-render-template.js` as the starting structure:
`configurePresentation()`, `renderSlide()`, per-component render
functions, `validateBounds()` and `validateReconstruction()`. Do not add a
separate diagonal line or overlay unless one is visibly an independent
object in the source; let shape geometry (e.g. a native chevron) create
the join between components.

### Step 6: Fidelity Validation

Render the generated slide and compare it against the source before
returning anything. Check for: elements present in the output but absent
from the source; artificial separators where two shapes simply meet;
duplicate edges (outline + separate line over the same boundary); z-order
problems; distorted aspect ratio; and text wrapping/line-count mismatches.

Read `references/fidelity-validation.md` for the full rule set (source-only
rule, no-artificial-separator rule, native-geometry rule, seam/overlap
rule, gradient rule, aspect-ratio rule) with correct/incorrect examples.

### Step 7: Common Pitfalls Checklist

Before delivering output, run it against the full checklist in
`references/common-pitfalls-checklist.md`: shape fidelity, layout
fidelity, typography fidelity, colour/styling fidelity, artifact quality,
and design craft fidelity (the six fundamentals from the PPT Creation
Rules section, for any element that involved a design decision rather
than a direct copy of the source). Fix anything that fails before
returning the final files.

### Step 8: Deliverables

Return, in this order:

1. **Design audit** — the Step 1-3 findings, condensed to what is useful
   for the user to review (not necessarily every raw measurement).
2. **Fidelity validation summary** — what was checked, whether native
   shapes were used, any approximations made, and any remaining
   limitations. Do not claim exact fidelity the source cannot support.
3. **JavaScript source** — the complete, commented, data-driven PPTXGenJS
   script, built via `create_file` (this is a code artifact per the
   file-creation rules for this session).
4. **PowerPoint artifact** — run the script (Node.js, with `pptxgenjs`
   installed) to produce `recreated-slide.pptx`, save it to
   `/mnt/user-data/outputs/`, and present it with `present_files`.
5. **Optional preview** — a rendered preview image used for validation,
   if supported in the current environment. This is for QA only; it does
   not replace the editable `.pptx`.
6. **Optional web output** — only if the user explicitly asks for HTML,
   React, Vue or SVG. See `references/web-output.md` for how to reuse the
   same data model for a web version without introducing decorative
   pseudo-elements that create non-source lines or seams.

## Coding Standards

- Use meaningful component names; keep content separate from layout logic.
- Store repeated style values as tokens; use helper functions for
  coordinate conversion (px to inches).
- Validate all object bounds and warn on out-of-bounds elements.
- Do not introduce visual embellishments or extra assets.
- Use Australian English in comments and any prose output.
- Preserve the user's supplied wording; do not infer missing content; label
  estimates and approximations clearly.

## Final Quality Gate

Before returning the deliverables, confirm the answer to this question is
"yes":

> Does the generated PowerPoint reproduce only the visible source
> elements, using the simplest faithful PowerPoint-native construction,
> without introducing additional lines, seams, borders, shadows, clipping
> or layout distortions?

If "no": identify the mismatch, fix the implementation, re-render, and
re-check before returning the corrected output.

## References

- `references/design-audit-checklist.md` — full Step 1 audit categories
  (canvas, layout, colour, typography, components, spacing, shape geometry,
  iconography) with worked examples.
- `references/fidelity-validation.md` — Step 6 validation rules (source-only,
  no-artificial-separator, no-duplicate-edge, native-geometry, seam/overlap,
  text-wrapping, gradient, z-order, aspect-ratio) with correct/incorrect
  examples.
- `references/common-pitfalls-checklist.md` — the Step 7 pass/fail checklist
  across shape, layout, typography, colour/styling, artifact quality and
  design craft fidelity.
- `references/ppt-creation-rules.md` — the PPT Creation Rules section in
  full: the six design fundamentals (audience, layout, colour, spacing &
  sizing, typography, icons & images), each with a guiding principle,
  five-question checklist and worked "what good looks like" examples,
  plus the four closing design habits and the scope/limits of
  accelerator packs and in-app AI copilots.
- `references/powerpoint-shortcuts-and-tricks.md` — mouse, textbox and
  keyboard shortcuts, workflow accelerators (Quick Access Toolbar,
  personal elements pack), gradient/transparency polish tricks, and
  bespoke-shape tricks (Change Shapes, Edit Points, Merge Shapes) for a
  user editing the output by hand.
- `references/web-output.md` — how to reuse the data model for optional
  HTML/React/Vue/SVG output when explicitly requested.
- `scripts/slide-data-model-example.js` — worked example of the Step 4
  structured data object for a multi-step chevron process slide.
- `scripts/pptxgenjs-render-template.js` — reusable PPTXGenJS render
  skeleton (configurePresentation, renderSlide, renderChevron,
  renderContentPanel, renderBodyText, renderNoteText, validateBounds,
  validateReconstruction) to adapt per task.

# Common Pitfalls Checklist (Step 7 Detail)

The output must pass every applicable check before delivery.

## Shape Fidelity

- [ ] Native PowerPoint shapes were used where appropriate.
- [ ] No unnecessary custom geometry was introduced.
- [ ] No artificial diagonal lines were added.
- [ ] No duplicate outlines or edge overlays exist.
- [ ] Chevron points align consistently.
- [ ] Connected shapes have no unintended gaps or seams.
- [ ] Shape adjustment values match the source.

## Layout Fidelity

- [ ] Slide ratio matches the source or requested format.
- [ ] Component count matches the source.
- [ ] All regions appear in the correct order.
- [ ] X and Y positions match the audit.
- [ ] Widths and heights match the audit.
- [ ] Panels align with their corresponding headers.
- [ ] Margins and gaps are consistent.
- [ ] No component extends outside the slide unintentionally.

## Typography Fidelity

- [ ] Font family matches or uses a documented fallback.
- [ ] Font sizes match.
- [ ] Font weights match.
- [ ] Font colours match.
- [ ] Italic and underline treatments match.
- [ ] Text wrapping matches.
- [ ] Text is not clipped.
- [ ] Auto-fit has not caused inconsistent sizes.
- [ ] No content was rewritten without instruction.

## Colour and Styling Fidelity

- [ ] Fill colours match the audit.
- [ ] Gradient colours and direction match.
- [ ] Border colours and widths match.
- [ ] No unintended shadows appear.
- [ ] No transparency was introduced without evidence.
- [ ] No anti-aliasing artifact was mistaken for a border.

## Artifact Quality

- [ ] The `.pptx` opens successfully.
- [ ] All major objects remain editable.
- [ ] The slide renders without errors.
- [ ] No objects overlap unintentionally.
- [ ] No warning text or debug objects remain.
- [ ] The output directory contains only the requested final deliverables.
- [ ] The generated JavaScript reproduces the supplied `.pptx`.

## Design Craft Fidelity

Apply this category wherever a design decision was made rather than
copied directly from the source (an ambiguous or incomplete source, a
from-scratch slide, or a design review). See
`references/ppt-creation-rules.md` for the full guiding principles
behind each item.

**Audience**
- [ ] It is clear who the slide is designed for.
- [ ] The slide does not assume terminology or context the audience has
      not already been given.
- [ ] The document's purpose (buy-in, advice, approval) is reflected in
      how the content is presented.
- [ ] The intended message or recommendation is identifiable at a glance.

**Layout**
- [ ] The most important element is positioned to be seen first.
- [ ] The slide makes 1-3 points, or is deliberately structured if it
      must make more.
- [ ] Content that could be shown (graph, image, icon) has not been left
      as plain text by default.
- [ ] Related items are grouped, not scattered.
- [ ] No point is repeated in a slightly different form elsewhere on the
      slide.

**Colours**
- [ ] The most important content is the easiest to see quickly.
- [ ] Colours pair well and make sense together (and against the pack's
      theme, if one applies).
- [ ] The number of colours in play is neither excessive (losing focus)
      nor insufficient (failing to emphasise or group anything).
- [ ] Every colour used is doing a job: focusing attention, evoking a
      specific meaning, or grouping like elements.

**Spacing & Sizing**
- [ ] Elements are evenly spaced and aligned, not eyeballed.
- [ ] Like elements are the same size as each other.
- [ ] Element positions are consistent with equivalent elements on other
      slides in the same deck.
- [ ] The slide has enough whitespace to avoid feeling crowded, without
      feeling empty.

**Typography**
- [ ] A clear text hierarchy (heading/subheading/body) is in place.
- [ ] Text size, weight and font are consistent across the slide and the
      pack.
- [ ] Text is grouped under headings rather than left as a single
      undifferentiated block.
- [ ] Parallel text blocks use comparable line counts where practical.

**Icons & Images**
- [ ] Any icon or image used genuinely communicates faster than text
      would, rather than decorating for its own sake.
- [ ] Icons and images make sense to the intended audience.
- [ ] Visuals fit the slide's colour theme rather than clashing with it.
- [ ] Images are high resolution and in focus (unless blur is a
      deliberate choice).

---

## Deliverable Content Reference (Step 8 Detail)

### Design Audit

Provide: canvas analysis, layout and geometry, colour palette, typography,
component inventory, spacing and border rules, shape mapping, design
rules, and identified uncertainties.

### Fidelity Validation Summary

State: what was visually checked, whether native shapes were used,
whether any approximations were necessary, whether any visible artifacts
were found and corrected, and any remaining limitations. Do not claim
exact fidelity if the source does not provide enough information to
verify it.

### JavaScript Source

Must be: self-contained, clearly commented, data-driven, built from
reusable functions, free of editable content hardcoded inside renderer
functions, free of unexplained magic numbers, and with all coordinates
traceable to the audit or layout constants.

### PowerPoint Artifact

Generate `recreated-slide.pptx` (or an appropriately named equivalent).
The file must contain editable components, not a flattened image.

### Optional Preview

Where supported, also provide a rendered preview used for validation.
The preview is for quality assurance only and does not replace the
editable PowerPoint artifact.

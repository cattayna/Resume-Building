# Design Audit Checklist (Step 1 Detail)

Analyse the supplied slide carefully and extract the following categories.
Do not add elements that are not visibly present in the source.

## 1.1 Canvas and Slide Dimensions

Record:

- Source image width and height
- Source aspect ratio
- Intended PowerPoint slide ratio
- PowerPoint slide width and height
- Any cropping visible in the source
- Whether the design reaches the slide edges
- Whether the source appears to show an entire slide or only a selected
  component

Example:

```text
Source size: 847 x 348 px
Source ratio: 2.434:1
Target PowerPoint size: Custom ratio matching source
Visible crop: None
Edge behaviour: Design runs to the left, top and right edges
```

Do not force the design into 16:9 if doing so would stretch, distort or
reposition the source composition.

## 1.2 Layout and Structure

Identify:

- Overall grid or layout system
- Columns, rows and overlays
- Absolute-positioned elements
- Named regions and zones
- Dimensions and proportions of each region
- X and Y coordinates
- Width and height of each component
- Padding, margins and gaps
- Alignment relationships
- Overlapping components
- Z-order and layering
- Repeated spacing patterns
- Text-box boundaries
- Whether components intentionally extend outside their nominal column

Use both pixel estimates from the source and converted PowerPoint
measurements in inches.

Example:

```text
Region: Step 1 header
Pixel bounds: x 0, y 0, width 240, height 126
PowerPoint bounds: x 0.00, y 0.00, width 2.40, height 1.26
Alignment: Top-left
Layer: Above Step 1 content panel
```

## 1.3 Colour Palette

Record every distinct visible colour.

```text
Role          | Hex / RGB | Usage
--------------|-----------|-----------------------------
Step 1 Header | #526B26   | First process chevron
Step 2 Header | #86BC25   | Second process chevron
Step 3 Header | #727272   | Third process chevron
Step 4 Header | #A1A1A1   | Fourth process chevron
Body Green    | #526B26   | Body copy in Steps 1 and 2
Note Accent   | #86BC25   | Italic supporting notes
Text Dark     | #111111   | Body copy in Steps 3 and 4
White         | #FFFFFF   | Heading text and shape separation
```

For gradients, record:

- Gradient type
- Start colour
- End colour
- Direction or angle
- Stop positions
- Transparency, if visible

Do not describe a gradient as a flat fill.

## 1.4 Typography

Record every distinct text style.

```text
Style Name  | Font Family | Size | Weight | Colour | Case | Alignment
------------|-------------|------|--------|--------|------|----------
Step Title  | Arial       | 20pt | 700    | White  | Title| Left
Body Text   | Arial       | 16pt | 400    | Olive  | Sentence | Left
Note Text   | Arial       | 14pt | 400    | Green  | Sentence | Left
```

Also record: line spacing, paragraph spacing, character spacing, italic or
underline treatment, internal text-box margins, vertical alignment, bullet
type and indentation, text wrapping, explicit line breaks, text-box fit
behaviour, and whether PowerPoint auto-fit should be disabled.

Do not change wording or insert line breaks solely to make implementation
easier.

## 1.5 Component Inventory

List every distinct component type and describe its anatomy, e.g.:

- **Process Chevron**: Native PowerPoint chevron with solid fill, no
  internal divider and bold white title.
- **Content Panel**: Rectangular background aligned directly below the
  corresponding chevron.
- **Body Text Box**: Left-aligned supporting paragraph with fixed line
  wrapping.
- **Note Text Box**: Italic accent text positioned beneath the body copy.
- **Column Separator**: Visible gap between content panels only where
  present in the source.

For each component, identify whether it should be implemented as: native
PowerPoint shape, text box, image, SVG, grouped component, table, chart,
connector, freeform polygon, or reusable custom renderer.

## 1.6 Spacing and Border Rules

Document: corner radius, border width, border colour, border transparency,
internal padding, external margins, gap between siblings, overlap depth,
separator thickness, shape-adjustment values, shadow parameters, and line
caps/joins.

Explicitly distinguish among: a visible border, a gap between shapes, a
background showing through, an intentional separator, and an
anti-aliasing or screenshot artifact. Do not automatically turn a visible
gap into a drawn line.

## 1.7 Shape Geometry

For each non-rectangular component, document: native PowerPoint shape
type, polygon points (if a native shape is unsuitable), orientation,
rotation, adjustment-handle position, arrowhead depth, inset depth,
overlap with adjacent shapes, whether the shape has a line or only a
fill, and whether the edge is created by shape geometry or a separate
object.

Example:

```text
Component: Process chevron
Preferred implementation: pptx.ShapeType.chevron
Border: None
Separator: Created by spacing or shape boundary
Internal diagonal line: Not present
Additional overlay: Not permitted
```

## 1.8 Iconography and Images

Record: icon style, icon dimensions, placement relative to text, fill and
outline colours, image crop, image transparency, aspect ratio, whether the
asset is embedded or generated, and whether a PowerPoint icon, SVG or
raster image is most appropriate.

Do not replace a simple native PowerPoint shape with a raster image unless
necessary.

---

## Design Rules (Step 2)

After the audit, summarise the implicit design system as a numbered list.
Examples:

1. Process stages run continuously from left to right.
2. Each process heading is contained within a native chevron.
3. Shape geometry creates the process transition.
4. No decorative diagonal line is placed over the chevrons.
5. Adjacent chevrons may overlap or use controlled spacing to create a
   clean join.
6. Header text is white, bold and vertically centred.
7. Content panels align directly beneath their corresponding headers.
8. Green headers use green-tinted content panels.
9. Grey headers use grey-tinted content panels.
10. Supplementary notes appear only when provided in the source.
11. Text wrapping must match the source as closely as possible.
12. Colours encode process grouping and must not be altered for
    stylistic preference.
13. No border, shadow, separator or decoration may be introduced unless
    visible in the source.

---

## PowerPoint Component Mapping (Step 3)

Priority order for every audited component:

1. Native PowerPoint shape
2. Native PowerPoint text box
3. Native PowerPoint table or chart
4. PowerPoint connector
5. SVG
6. Freeform polygon
7. Raster image
8. HTML or CSS approximation, only when explicitly requested

Example:

```text
Source element        | PowerPoint implementation
----------------------|--------------------------------
Process arrow         | pptx.ShapeType.chevron
Body panel            | pptx.ShapeType.rect
Step heading          | Text inside chevron
Body paragraph        | slide.addText()
Supporting note       | slide.addText() with italic style
Panel gradient        | Native gradient if supported, otherwise validated fallback
```

### Native Shape Rule

Do not simulate a native PowerPoint shape using pseudo-elements, skewed
rectangles, decorative diagonal lines, layered borders, multiple
overlapping shapes that create visible seams, or HTML `clip-path` (unless
HTML output was specifically requested). If a native PowerPoint chevron
exists, use it rather than constructing one from rectangles and line
overlays.

### SmartArt Rule

If the design resembles SmartArt, identify the likely SmartArt family,
layout type, number of stages, direction, shape type and connection
model. The reconstruction does not need to retain editable SmartArt if
the library cannot produce it, but it must use editable PowerPoint shapes
that visually and structurally match the source. Do not label a design as
SmartArt with certainty unless the source or supplied PowerPoint
structure confirms it; use terms such as "SmartArt-style process" when
only visual evidence is available.

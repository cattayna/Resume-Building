# Fidelity Validation and Common-Pitfall Detection (Step 6 Detail)

This step is mandatory. Before returning the JavaScript or `.pptx`, render
the generated slide and compare the rendered output with the source.

## 6.1 Source-Only Rule

The generated slide must not contain any visible element that is absent
from the source. This includes: lines, dividers, borders, shadows,
highlights, gradients, icons, arrowheads, background blocks, decorative
overlays, additional text, and extra whitespace caused by incorrect
positioning.

If the source does not visibly contain an element, do not create it.

## 6.2 No Artificial Separator Rule

Do not add a separator line merely because two coloured shapes meet.
First determine whether the visible transition is created by: shape
geometry, shape spacing, shape overlap, background exposure, or a genuine
line object. For connected chevrons, the boundary should normally be
created by the chevron geometry itself.

Incorrect:

```text
[ Step 1 / ]
```

Correct:

```text
[ Step 1 > ][ Step 2 > ]
```

An internal diagonal slash is a reconstruction defect unless it is
visibly present in the source.

## 6.3 No Duplicate Edge Rule

Do not create both a shape outline and a separate line over the same
edge. This can cause double-width borders, bright seams, internal
slashes, uneven joins, and rendering differences between PowerPoint and
preview images. Use either the native shape boundary or a separate line,
not both, unless the source clearly requires both.

## 6.4 Native Geometry Rule

If a native shape accurately represents the source, use it. Do not
construct a chevron by combining a rectangle, a triangle, a white
diagonal line and a masking shape, unless a native chevron demonstrably
cannot match the source.

## 6.5 Seam and Overlap Rule

Check all adjoining shapes at 100% zoom. Reject or correct the output if
it contains: hairline gaps, white seams, doubled edges, misaligned arrow
points, uneven overlap, visible background between connected shapes,
one-pixel alignment differences, overlapping text, or text clipped by
shape boundaries.

## 6.6 Text-Wrapping Rule

Compare the source and generated output for: number of lines,
approximate break positions, text-box width/height, paragraph spacing,
font size, and vertical alignment. Do not reduce the font size before
checking, in order: text-box dimensions, internal text margins, font
family, character spacing, paragraph spacing, and auto-fit settings.

## 6.7 Gradient Rule

If the source contains a gradient: reproduce the direction, match start
and end colours, match the approximate transition, check for banding, and
ensure the gradient does not extend into neighbouring panels. If
PPTXGenJS cannot reproduce the gradient faithfully, use the closest
editable fallback and state the limitation. Do not silently replace a
gradient with an unrelated flat fill.

## 6.8 Z-Order Rule

Validate that: header shapes sit above panels where required, backgrounds
remain behind text, overlapping chevrons use the correct front-to-back
order, text remains visible, and masking elements do not cover source
content.

## 6.9 Aspect-Ratio Rule

Do not force the source into a different ratio without proportional
adaptation. Reject any output that introduces horizontal or vertical
stretching, distorted arrows, changed text wrapping solely due to slide
resizing, unbalanced margins, or unintended cropping.

## 6.10 Visual Difference Review

After rendering, review at least: overall composition, component count,
shape positions, shape sizes, colour matches, text wrapping, alignment,
negative space, borders, joins, shadows, gradients, and layering. Correct
visible differences before returning the final output.

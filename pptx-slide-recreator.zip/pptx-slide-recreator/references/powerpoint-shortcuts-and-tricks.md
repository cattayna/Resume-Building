# PowerPoint Shortcuts and Workflow Tricks

Source: JR PowerPoint Design Training (Deloitte Consulting Craft, 2026).
These speed up manual, human PowerPoint editing (time to develop).
They are reference material for the human end-user of a generated
`.pptx`, not something the PPTXGenJS build script does itself. Surface
these when the user is editing the output by hand, asking for
PowerPoint tips, or asking how to speed up their own slide-building
workflow; they have no direct bearing on the Step 5 code generation
itself.

## Mouse pointer shortcuts

| Action | Shortcut | Effect |
|---|---|---|
| Move on an axis | Hold **Shift** while moving | Snaps movement to the vertical or horizontal axis |
| Duplicate an element | Hold **Control** while moving | Duplicates the element as you drag |
| Move freely | Hold **Alt** while moving | Stops the element snapping to other elements' alignment guides |
| Lock aspect ratio | Hold **Shift** while resizing | Keeps the aspect ratio fixed while resizing |
| Stretch an element | Hold **Control** while resizing | Mirrors the resize to the opposite side |
| Resize freely | Hold **Alt** while resizing | Stops the resize snapping to alignment guides |

These combine: holding **Control + Shift** while dragging duplicates an
element and keeps it on its horizontal or vertical axis at the same
time.

## Textbox shortcuts

| Action | Shortcut |
|---|---|
| Move cursor between words | **Control** + arrow key |
| Select text | **Shift** + arrow key |
| Indent text | **Shift + Alt** + left/right arrow |
| Rotate the text box | **Alt** + left/right arrow (rarely needed) |

These also combine, e.g. **Control + Shift** + arrow key selects whole
words at a time rather than single characters.

## General keyboard shortcuts

| Action | Windows | Mac |
|---|---|---|
| Copy | Control + C | Command + C |
| Paste | Control + V | Command + V |
| Cut | Control + X | Command + X |
| Copy formatting | Control + Shift + C | Command + Shift + C |
| Paste formatting | Control + Shift + V | Command + Shift + V |
| Duplicate | Control + D / Control + Click & Drag | Command + D / Control + Click & Drag |
| Select all | Control + A | Command + A |
| New slide | Control + M | Command + Shift + N |
| Bring forward | Control + Shift + ] | Option + Shift + Command + F |
| Bring backward | Control + Shift + [ | Option + Shift + Command + B |
| Screen capture | Windows + Shift + S | Command + Shift + 4 |
| Make shape wider / narrower / taller / shorter | Shift + Right/Left/Up/Down arrow (hold Control too for smaller increments) | Same |
| Group | Control + G | Command + Option + G |
| Ungroup | Control + Shift + G | Command + Option + Shift + G |
| Align text left / centre / right | Control + L / E / R | Command + L / E / R |
| Justify text | Control + J | Command + J |
| Find | Control + F | Command + F |
| Find & Replace | Control + H | Command + Shift + H |
| Bold / Italics / Underline | Control + B / I / U | Command + B / I / U |
| Increase / decrease font size | Control + ] / [ , or Control + Shift + > / < | Command + Shift + > / < |
| Undo / Redo | Control + Z / Y | Command + Z / Y |
| Toggle case (upper/lower/sentence/capitalise) | Shift + F3 | Shift + F3 |

**Copy/paste formatting** (Control/Command + Shift + C then V) and
**resize by arrow key** (Shift + arrow) are the two most time-saving
shortcuts for a user doing frequent manual formatting, ahead of the
less-used shape rotation shortcut.

## Workflow accelerators

- **Quick Access Toolbar** — a customisable toolbar for the PowerPoint
  features used most often, so switching between ribbon tabs is rarely
  needed. Can be driven entirely from the keyboard using Alt plus the
  letter shown for each item.
- **A personal accelerator/elements pack** — a saved library of reusable
  slide components (commonly used elements, section separator slides,
  card layouts, key-point layouts, process diagrams, timelines, avatar
  sets) built up over time so components are not recreated from
  scratch. Treat it as a source of inspiration and a time-saver, not a
  substitute for understanding the message a given slide needs to
  carry (see `ppt-creation-rules.md`).

## Fill and blend tricks (polish, not substance)

- **Subtle gradient fill** — a light gradient (e.g. one shade of
  difference between the two stops) reads as a premium, polished touch,
  as used in many consumer products. Trade-off: a solid fill is faster
  to change and edit later, so use gradients selectively rather than by
  default.
- **Gradient into background** — fade a shape's gradient to full
  transparency at one end so it blends into the slide background; a
  neat way to group elements without a hard edge.
- **Transparency blending** — reduce the fill or text transparency
  (e.g. ~85%) to create a faded, de-emphasised element; useful for
  conveying something like a step number without drawing the eye to it
  as strongly as fully opaque text would.

## Bespoke shape tricks

Use these only when a native PowerPoint shape cannot do the job (per
the Native Shape Rule in `design-audit-checklist.md` for the PPTXGenJS
build itself; this section is about manual editing in the PowerPoint
UI).

- **Change Shapes** — select a shape, then Shape Format → Edit Shape →
  Change Shape, to swap one native shape for another (e.g. a rounded
  rectangle for a square-cornered one) while keeping its content.
- **Edit Points** — right-click a shape → Edit Points, then drag the
  black points to reshape it. Right-click an individual point to change
  it between corner, smooth and straight. Useful for custom polygons,
  e.g. extending a pyramid layer into a connected callout shape.
- **Merge Shapes** — select multiple shapes in the order you want the
  operation applied, then Shape Format → Merge Shapes → Union / Combine
  / Fragment / Intersect / Subtract:

  | Operation | Effect |
  |---|---|
  | Union | Combines the shapes into one |
  | Combine | Merges shapes and removes the overlapping area |
  | Fragment | Splits the shapes into their intersecting pieces |
  | Intersect | Keeps only the overlapping area |
  | Subtract | Removes the front shape's area from the back shape |

  Grouped shapes cannot be merged; ungroup first. Useful for, for
  example, building a single "overall objective" shape with
  short/long-term activity callouts merged out of simple rectangles.

## Using AI copilots in PowerPoint

See the "Accelerator packs and AI tools" section of
`ppt-creation-rules.md` for what current in-app AI assistants are and
are not reliable for (spelling/grammar checks, text iteration and
speaker-note drafting are reliable with review; straplines and
whole-slide generation are not yet reliable).

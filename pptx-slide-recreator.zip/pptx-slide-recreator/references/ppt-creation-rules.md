# PowerPoint Creation Rules: The Six Design Fundamentals

Source: JR PowerPoint Design Training (Deloitte Consulting Craft, 2026),
slide pack and session transcript. These are general slide-craft rules,
distinct from the Step 1-7 source-recreation workflow in `SKILL.md`. Apply
them whenever a task calls for judging or improving slide quality, not
only reconstructing an existing slide: when a source is ambiguous or
incomplete and a design decision must be made, when the user asks for a
new slide rather than a recreation, or when the user asks for a design
review or critique.

## Why design quality matters

Three reasons to take slide design seriously, carried through everything
below:

1. Consulting materials are not information containers or pretty
   pictures; they are **decision instruments**. Good design enables an
   audience to make good decisions.
2. Whoever builds the slide usually has more influence than they realise
   over how the message is understood and acted on, because they are the
   one translating an idea into a visual artefact.
3. Poorly designed materials increase review cycles, rework costs,
   interpretive debate and even emotional friction. Quality design
   reduces this organisational drag.

The underlying mechanism is **cognitive load**. A design with an unclear
objective, mixed messaging, inconsistent structure, visual clutter and no
explicit recommendation forces the audience to do the work the slide
should have done. A design with a clear objective up front, logical
narrative flow, structured evidence, clean visual hierarchy and an
explicit recommendation requires low cognitive load and is quicker and
more reliable to act on.

Perceptions of "good" design are ultimately subjective. The real measure
of success is **clarity and decision quality**: does the slide clearly
communicate the intended message, and does it help the audience decide
accurately and faster. Treat every rule below as a means to that end,
not an end in itself.

## How to use the six fundamentals

Each fundamental below has: a guiding principle, five checklist
questions to run against any slide, and notes on what good execution
looks like for that fundamental. Work through all six for any new slide;
for a slide you are auditing or reviewing, use them as the basis for
feedback.

### 1. Audience

**Principle:** Design is a plan for arranging elements in such a way as
to best accomplish a particular purpose (Charles Eames). Every slide
needs to start with the audience, not the content.

**Checklist:**
1. Who am I designing for? (executives, broader workforce, internal
   stakeholders)
2. What do they need to know before they can understand your slide?
   (frameworks, terminology, decisions already made)
3. What do they already know? (prior findings, concepts, recommendations
   you can build on rather than repeat)
4. What is the document's purpose? (buy-in, advising clients, gaining
   approval)
5. What is the message I want to give? (the story, whether action is
   needed, the ideal outcome)

Design is about purpose, not decoration; if a design choice does not
serve one of these five answers, question whether it belongs.

**What good looks like**, matched to use case:

| Style | Description | Good for |
|---|---|---|
| Minimalistic | Small amount of content and few slide elements; quick to read | Executives, workshops |
| Detailed | Comprehensive, content-heavy; takes longer to read and understand | Deliverables, proposals |
| Conceptual | "Show not tell" using images and colour to convey the message | Deliverables, workshops, executives, proposals |
| Wordy | Text-only, not quick to digest, but gives necessary context | Introduction sections, proposals |

Detailed slides are the majority of slides produced in deliverables, so
choosing content carefully for this style matters most.

### 2. Layout

**Principle:** Make everything as simple as possible, but no simpler
(Albert Einstein). The layout always directs the audience's attention to
specific elements, so be intentional about where everything sits.

**Checklist:**
1. What needs to be seen first? (the key message, a graph legend or key
   needed before the graph itself makes sense; most layouts are read
   left to right)
2. How many points am I making? (1-3 is generally plenty; if more,
   structure it accordingly, and check whether there are hidden
   subpoints)
3. Can I show instead of tell? (graphs, images, illustrations, icons,
   instead of plain text that takes longer to read and costs more
   cognitive load)
4. Can items be grouped simply? (what things are related; a rough
   storyboard or wireframe first can establish the minimum viable layout
   before detail is added)
5. Have I repeated myself? (the same point restated in a slightly
   different way; look for what can be combined or removed)

**What good looks like:**

| Pattern | Description | Good for |
|---|---|---|
| Storyboard | Map where slide elements go using shapes first, before content | The majority of slides |
| Multiple points | Give the audience context before the key point and options | Options, key points |
| Visuals | An illustration quickly shows the slide's purpose | The majority of slides |
| Timelines | A simple view of phases, activities, milestones | Plans, proposals |
| Processes | Steps in order, e.g. via chevron shapes | Approaches, processes |
| Tables | Various layouts depending on content | Assessments, processes, lists |

### 3. Colours

**Principle:** Colour is the first element the mind sees and the last it
forgets. Colour is non-verbal communication, so it must be used on
purpose, not decoratively.

**Checklist:**
1. What is most important to see quickly? (use colour to emphasise a key
   message, or to group related elements)
2. Have I used colours that pair well? (complementary colours, sensible
   shades)
3. Do my colours make sense? (consider accessibility, use the pack's
   theme, keep colours consistent with other slides, keep legends/keys
   clear)
4. Have I used too many colours? (can you still maintain focus; is each
   colour adding value, not just drawing the eye everywhere)
5. Have I used enough colours? (what can be emphasised, what mood can be
   evoked; plain black-and-white may be a deliberate choice but check it
   is intentional)

Colour should always have a job to do: focus attention, evoke an
emotion, or link like elements. Do not introduce a colour that does none
of these.

**What good looks like:**

- **Focus attention** — use colour to guide the eye to where you want it
  to land first (key messages, key actions), even ahead of natural
  left-to-right reading order.
- **Colour psychology** — colour can evoke emotion and meaning (e.g.
  green for good/go/growth, red for bad/stop, or for passion/energy
  depending on context). Good for evoking a mood or for maturity
  assessments (red flags an immature capability needing attention).
- **Complementary colours** — pair colours that sit well together for a
  more aesthetically pleasing result. Good for the majority of slides.
- **Colour shades** — use different shades of a single colour for a
  cohesive feel (e.g. a light tint background, darker text, a faded
  accent). Keep text colour as a shade of the shape it sits in or on;
  further/supporting information can use a lighter shade. Good for the
  majority of slides.
- **Group elements** — use colour to group like elements with a clear
  purpose (options, phases in a plan, separating slide sections). Good
  for options, phases, separating elements.

### 4. Spacing & Sizing

**Principle:** Whitespace is like air: it is necessary for the design to
breathe. Whitespace is not wasted space. Creating hierarchy, space and
alignment lets the reader navigate a well-balanced design quickly.

**Checklist:**
1. Are elements spaced evenly? (use the Distribute feature; same gap
   distances, vertically and horizontally)
2. Do elements align well to each other? (use the Align feature)
3. Are like elements the same size? (shape sizes, number of text lines,
   image sizes kept consistent so the audience can quickly link related
   items)
4. Do elements change position across slides? (keep positions consistent
   across a deck; elements that "wobble" between slides read as
   unpolished)
5. Have I used enough whitespace? (does it feel crowded, does it feel
   empty; find the balance)

**What good looks like:**

- **Even distribution** — elements should generally have the same
  horizontal and vertical distance from other elements. Good for lists,
  processes.
- **Even alignment** — elements should always align vertically and
  horizontally; this conveys thoughtfulness and professionalism. Good
  for all slides.
- **Whitespace as emphasis** — use whitespace to emphasise the
  importance of what you place on the slide. Good for executives,
  workshops.
- **Size consistency** — keep sizes of like elements consistent so the
  audience can see the link between them quickly. Good for the majority
  of slides.

Repeated, intentional use of distribution and alignment signals that
real thought went into the document and reads as higher quality, even on
low-stakes content like a table of contents.

### 5. Typography

**Principle:** The beauty of type lies in its utility; prettiness
without readability serves neither the author nor the reader. Typography
is about readability and hierarchy: if the audience cannot quickly scan
the slide, the hierarchy is not working.

**Checklist:**
1. Have I created a clear text hierarchy? (headings, subheadings,
   paragraph text)
2. Is my text a consistent size and weight? (especially across the whole
   pack; be consistent and not excessive when bolding keywords)
3. Can my text be clearly grouped? (use headings so the audience can
   choose whether to read the detail underneath; a lone paragraph forces
   a full read just to learn the point)
4. Is my text a consistent font in the pack? (usually dictated by the
   template; Deloitte's base font is Open Sans)
5. Can I utilise consistent line amounts? (matching line counts across
   parallel text blocks reduces eye movement and signals a tidier
   design)

**What good looks like:**

- **Text hierarchy** — titles, headings, subheadings and paragraph text
  guide the order in which the audience reads the slide, exploiting how
  people naturally scan a page. Good for the majority of slides.
- **Text grouping** — headings let the reader move between groups of
  content at their own pace. Good for the majority of slides.
- **Font size & weight** — larger, bolder text focuses attention
  quickly; smaller text is reserved for supporting detail. Good for the
  majority of slides.
- **Font choice** — usually fixed by the pack's theme, but font choice
  does convey a message by itself when designing a pack from scratch.
  Good for designing your own packs.

### 6. Icons & Images

**Principle:** A picture is worth a thousand words. Visual elements
illustrate and connect the audience to the narrative, story and key
messages.

**Checklist:**
1. Can I use visuals to communicate? (what's the key message; is there
   enough room; could a visual replace some of the text rather than
   adding to it)
2. Do my icons make sense to the audience? (get a second opinion if
   unsure; get familiar with PowerPoint's native icon set; search for
   ideas rather than guessing)
3. Do my visuals fit the slide design? (use the pack's colour theme;
   blend with transparency; crop or edit as needed so visuals do not
   contrast so strongly they pull attention from the key message)
4. Are my images high resolution and in focus? (occasional deliberate
   blur aside, default to sharp, high-resolution images)
5. Can I use illustrations to fill space? (depends on the content; not
   every slide needs one)

**What good looks like:**

- **Relevant icons** — icons that relate to the slide's content orient
  the audience quickly. Good for lists, tables of contents, breadcrumbs,
  guiding principles.
- **Relevant illustrations** — illustrations that relate to and support
  the text, never replace the need for it. Good for executives,
  workshops.
- **Cohesive design** — icons, numbers and illustrations used together
  with a consistent colour palette, blended with transparency where
  needed. Good for all slides.
- **Diagrams** — visual learners benefit from seeing a process
  represented rather than reading paragraphs about it.

**Image sources mentioned in the training:** use the organisation's
brand asset library for royalty-safe photography; royalty-free image
libraries (e.g. Unsplash) for high-quality photography; royalty-free
illustration libraries (e.g. unDraw) for recolourable illustrations;
and PowerPoint's native icon set for simple inline icons.

## Closing design discipline (apply to every slide)

Four habits to close out any design task, in the order they are most
useful:

1. **Be inspired, be creative.** Look for good design in the world
   around you (well-designed apps and products are a common source:
   subtle gradients, rounded corners, clear text hierarchy, evenly
   distributed and aligned elements, equal spacing) and bring those
   principles into your own slides using judgement, not by reinventing
   the accelerator pack from scratch each time.
2. **Understand the slide's message before building it.** If you do not
   understand what the slide needs to say, you cannot expect the
   audience to. Ask good questions, think critically, and do the
   research first; clarity has to start with the person building the
   slide.
3. **Ask for a second opinion.** Ask someone else whether they clearly
   understand the slide's message, and incorporate their feedback.
   Fresh eyes spot issues quickly and feedback is a reliable shortcut to
   a better design.
4. **Iterate.** The first draft is never the final draft. Each pass
   should improve the clarity of the message, not just the decoration.

## Accelerator packs and AI tools: scope and limits

- A personal or team accelerator/elements pack (reusable slide
  components: commonly used elements, section separators, card layouts,
  process diagrams, timelines, key-point layouts) exists to **accelerate
  thinking, not replace it**. Understand the message the slide needs to
  carry first, then look for an existing component in the pack that can
  express it faster.
- AI copilots embedded in Office tools are currently reliable for:
  spelling and grammar checks (ask for a list of issues to review before
  anything is actioned in the document, never auto-apply), iterating on
  text-based content (e.g. "give me three ways to phrase this key
  message"), and drafting speaker notes (always reviewed before use,
  never relied on at 100%).
- They are currently unreliable for: generating a short, sharp strapline
  from slide content (write your own, then iterate on it with the tool
  if useful); and building an entire slide or deck from scratch (good at
  recommending an approach or structure, not yet at producing
  high-quality finished content). A chat-based assistant may produce
  stronger output than an equivalent in-built function inside the
  PowerPoint application itself; if results in-app are weak, try the
  same prompt in a chat interface.

# Optional Web Output (Step 8.6 Detail)

Generate HTML, React, Vue or SVG output only when the user specifically
requests it. The PowerPoint `.pptx` built from PPTXGenJS remains the
primary deliverable and the source of truth for the design unless the
user says otherwise.

If web output is requested:

- Reuse the same central slide data model used for the PPTXGenJS build
  (see `scripts/slide-data-model-example.js`) rather than redefining
  content separately. Keep content, geometry, typography and colour
  tokens in one place.
- Do not use decorative pseudo-elements that introduce lines or seams
  that are not present in the source (for example, a CSS `::before`
  diagonal line standing in for a chevron point).
- Validate the web rendering separately from the PowerPoint rendering;
  passing fidelity checks in one format does not guarantee the other
  matches, since browsers and PowerPoint render shapes differently.
- Apply the same Step 6 fidelity rules (source-only, no artificial
  separators, no duplicate edges, correct z-order, correct aspect ratio)
  to the web version.
- State clearly which format is the primary editable deliverable and
  which is the supplementary web version, so the user is not left
  assuming the web version is also natively editable in PowerPoint.

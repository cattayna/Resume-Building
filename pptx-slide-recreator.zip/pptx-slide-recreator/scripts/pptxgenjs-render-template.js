/**
 * Reusable PPTXGenJS render skeleton (Step 5).
 *
 * Adapt this per task: populate slideData (see
 * slide-data-model-example.js) from the design audit, then fill in the
 * render functions below so every coordinate traces back to an audited
 * measurement, not a guess.
 *
 * Shape construction rule: for a chevron process, prefer the native
 * chevron shape with no separate diagonal line unless the source
 * clearly contains one as an independent visible object. Do not add a
 * separator merely because two shapes meet; let shape geometry create
 * the join (see references/fidelity-validation.md, section 6.2-6.4).
 *
 * Run with: node pptxgenjs-render-template.js
 * Requires: npm install pptxgenjs
 */

const pptxgen = require("pptxgenjs");

// --- Replace with the populated data model for the actual task. ---
const slideData = {
  metadata: {},
  slide: { widthInches: 13.333, heightInches: 7.5, background: "#FFFFFF" },
  tokens: {},
  typography: {},
  steps: [],
};

/**
 * Sets up the presentation-level layout to match the source slide's
 * aspect ratio (Step 1.1 / 6.9 aspect-ratio rule).
 */
function configurePresentation(pptx, data) {
  pptx.defineLayout({
    name: "SOURCE_MATCHED",
    width: data.slide.widthInches,
    height: data.slide.heightInches,
  });
  pptx.layout = "SOURCE_MATCHED";
}

/**
 * Renders the native PowerPoint process-chevron component
 * (design audit 1.5 "Process Chevron" / mapping rule: native shape
 * over custom geometry).
 */
function renderChevron(slide, step, bounds, tokens) {
  slide.addShape(pptx.ShapeType.chevron, {
    x: bounds.x,
    y: bounds.y,
    w: bounds.w,
    h: bounds.h,
    fill: { color: step.header.fill },
    line: step.header.line
      ? { color: step.header.line }
      : { color: step.header.fill, transparency: 100 }, // No visible outline.
  });

  slide.addText(step.title, {
    x: bounds.x,
    y: bounds.y,
    w: bounds.w,
    h: bounds.h,
    fontFace: tokens.fontFamily,
    fontSize: tokens.headingSizePt,
    bold: true,
    color: "FFFFFF",
    align: "left",
    valign: "middle",
    autoFit: false,
  });
}

/**
 * Renders the content-panel background aligned beneath its header
 * (design audit 1.5 "Content Panel").
 */
function renderContentPanel(slide, step, bounds, tokens) {
  const fillOptions =
    step.panel.fill.type === "gradient"
      ? {
          type: "gradient",
          colors: [step.panel.fill.from, step.panel.fill.to],
          angle: step.panel.fill.angle,
        }
      : { color: step.panel.fill.color };

  slide.addShape(pptx.ShapeType.rect, {
    x: bounds.x,
    y: bounds.y,
    w: bounds.w,
    h: bounds.h,
    fill: fillOptions,
    line: { color: step.panel.fill.color || "FFFFFF", transparency: 100 },
  });
}

/**
 * Renders the supporting paragraph (design audit 1.5 "Body Text Box").
 */
function renderBodyText(slide, step, bounds, tokens) {
  if (!step.body) return;
  slide.addText(step.body, {
    x: bounds.x,
    y: bounds.y,
    w: bounds.w,
    h: bounds.h,
    fontFace: tokens.fontFamily,
    fontSize: tokens.bodySizePt,
    color: tokens.colours ? tokens.colours.textDark : "111111",
    align: "left",
    valign: "top",
    autoFit: false,
  });
}

/**
 * Renders the optional italic note (design audit 1.5 "Note Text Box").
 * Omit entirely if the source has no note for this step.
 */
function renderNoteText(slide, step, bounds, tokens) {
  if (!step.note) return;
  slide.addText(step.note, {
    x: bounds.x,
    y: bounds.y,
    w: bounds.w,
    h: bounds.h,
    fontFace: tokens.fontFamily,
    fontSize: tokens.noteSizePt,
    italic: true,
    color: tokens.colours ? tokens.colours.noteAccent : "86BC25",
    align: "left",
    valign: "top",
    autoFit: false,
  });
}

/**
 * Renders one complete process stage: header, panel, body, note.
 * `bounds` for each sub-component should come from the Step 1.2 layout
 * audit, converted to inches, not estimated here.
 */
function renderProcessStep(slide, step, index, data) {
  const headerBounds = step.headerBounds; // { x, y, w, h } from audit.
  const panelBounds = step.panelBounds;
  const bodyBounds = step.bodyBounds;
  const noteBounds = step.noteBounds;

  renderContentPanel(slide, step, panelBounds, data.typography);
  renderChevron(slide, step, headerBounds, data.typography);
  renderBodyText(slide, step, bodyBounds, data.typography);
  if (noteBounds) renderNoteText(slide, step, noteBounds, data.typography);
}

function renderSlide(slide, data) {
  data.steps.forEach((step, index) => {
    renderProcessStep(slide, step, index, data);
  });
}

/**
 * Detects objects extending beyond the slide canvas (Step 1.2 /
 * coding-standards bounds validation).
 */
function validateBounds(data) {
  const warnings = [];
  data.steps.forEach((step) => {
    [step.headerBounds, step.panelBounds, step.bodyBounds, step.noteBounds]
      .filter(Boolean)
      .forEach((bounds) => {
        const right = bounds.x + bounds.w;
        const bottom = bounds.y + bounds.h;
        if (right > data.slide.widthInches || bottom > data.slide.heightInches) {
          warnings.push(
            `Element in step "${step.id}" extends beyond the slide canvas.`
          );
        }
      });
  });
  if (warnings.length) {
    console.warn("validateBounds warnings:\n" + warnings.join("\n"));
  }
}

/**
 * Checks for avoidable borders, duplicate lines, seams and unsupported
 * additions before writing the file (Step 6 fidelity rules).
 */
function validateReconstruction(data) {
  const warnings = [];
  data.steps.forEach((step) => {
    if (step.header.line && step.header.fill === step.header.line) {
      warnings.push(
        `Step "${step.id}" chevron defines both a fill and a same-colour ` +
          `outline; confirm this is not an unintended duplicate edge.`
      );
    }
  });
  if (warnings.length) {
    console.warn("validateReconstruction warnings:\n" + warnings.join("\n"));
  }
}

async function buildPresentation() {
  const pptx = new pptxgen();

  configurePresentation(pptx, slideData);
  validateBounds(slideData);
  validateReconstruction(slideData);

  const slide = pptx.addSlide();
  renderSlide(slide, slideData);

  await pptx.writeFile({ fileName: "recreated-slide.pptx" });
}

buildPresentation();

module.exports = {
  configurePresentation,
  renderSlide,
  renderChevron,
  renderContentPanel,
  renderBodyText,
  renderNoteText,
  renderProcessStep,
  validateBounds,
  validateReconstruction,
};

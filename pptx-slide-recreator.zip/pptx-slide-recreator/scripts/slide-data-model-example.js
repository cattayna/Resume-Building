/**
 * Worked example of the Step 4 "Slide Artifact Data Model".
 *
 * This is a reference structure to adapt per task, not a file to run
 * as-is. Copy the shape of this object, then populate it from the
 * design audit for the specific source slide (see
 * references/design-audit-checklist.md).
 *
 * Rules this structure must satisfy:
 * - No user-editable text is hardcoded inside rendering functions;
 *   it all lives here.
 * - Content, geometry, typography, colour tokens, component defaults
 *   and slide metadata are kept in separate sections.
 * - The structure mirrors the source slide's information hierarchy
 *   (e.g. one entry per process step, in left-to-right order).
 */

const slideData = {
  metadata: {
    title: "Four-Step Process",
    sourceWidthPx: 847,
    sourceHeightPx: 348,
    aspectRatio: 847 / 348,
  },

  slide: {
    widthInches: 12.7,
    heightInches: 5.22,
    background: "#FFFFFF",
  },

  typography: {
    fontFamily: "Arial",
    headingSizePt: 20,
    bodySizePt: 16,
    noteSizePt: 14,
  },

  tokens: {
    colours: {
      step1Header: "#526B26",
      step2Header: "#86BC25",
      step3Header: "#727272",
      step4Header: "#A1A1A1",
      bodyGreen: "#526B26",
      noteAccent: "#86BC25",
      textDark: "#111111",
      white: "#FFFFFF",
    },
  },

  // One entry per process stage, left to right, matching the source.
  steps: [
    {
      id: "step-1",
      title: "Step 1 Name",
      header: {
        shape: "chevron",
        fill: "#526B26",
        line: null, // No separate outline; chevron geometry is the edge.
      },
      panel: {
        fill: {
          type: "gradient",
          from: "#EAF7D4",
          to: "#FFFFFF",
          angle: 90,
        },
      },
      body: "Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Maecenas porttitor congue massa.",
      note: "Note: Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Maecenas porttitor congue massa.",
    },
    // Repeat one object per step, carrying over only what the audit
    // actually found for that step (e.g. omit `note` entirely if the
    // source slide has no note for a given step).
  ],
};

module.exports = { slideData };
